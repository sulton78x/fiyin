const SliderOne = () => {
  return (
    <div>
      <div>
        <h3>Most powerful football predictor</h3>
        <h4>
          Analyze all data and make smarter bets <br />
          Bookallbets is all you need in one tool.
        </h4>
      </div>
    </div>
  )
}

export default SliderOne
